# Follow-Up Prioritizer™ Public Package v1.0.1

Product SemVer: 1.0.0 (unchanged)
Public-package SemVer: 1.0.1
Change class: presentation-only Safe-Change successor

Delta:
- carousel_02.png repaired for headline overflow/safe-area fit.
- carousel_01.png, carousel_03.png, carousel_04.png, carousel_05.png preserved from the prior presentation set.
- product/application bytes are unchanged.

Frozen product identity remains:
9077a29629218d6345303d2a79f7cc4f45a12e6cabce8bef0a0b91616c3712bf
