# Day 1 — Follow-Up Prioritizer™

Five follow-ups can all look urgent at the same time.

So I built a small tool that forces the decision into the open: one ordered queue, with the exact reasons each item ranks where it does.

No black-box recommendation. No real customer data. Just a synthetic example showing overdue commitments, deadlines, engagement, opportunity signals, and contact age working together.

Day 1 is intentionally narrow: one repeated decision → one working proof.

Inspect the build. Download the example package.
