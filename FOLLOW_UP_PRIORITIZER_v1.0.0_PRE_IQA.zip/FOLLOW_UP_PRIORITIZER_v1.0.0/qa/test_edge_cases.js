require('../app/ranking.js');
const {prioritize,scoreItem}=globalThis.FollowUpRanking;
if(JSON.stringify(prioritize([]))!=='[]') throw new Error('empty input');
const tie=[
 {id:'B',days_since_contact:0,promised_followup_days_ago:0,opportunity_value:1,engagement:'low',deadline_days:99},
 {id:'A',days_since_contact:0,promised_followup_days_ago:0,opportunity_value:1,engagement:'low',deadline_days:99}
];
if(prioritize(tie).map(x=>x.id).join(',')!=='A,B') throw new Error('tie break');
const x=scoreItem({id:'X',days_since_contact:0,promised_followup_days_ago:0,opportunity_value:0,engagement:'low',deadline_days:99});
if(!Number.isFinite(x.score)||!x.reasons.length) throw new Error('basic score');
console.log('PASS empty_input');
console.log('PASS stable_tie_break');
console.log('PASS basic_score');
