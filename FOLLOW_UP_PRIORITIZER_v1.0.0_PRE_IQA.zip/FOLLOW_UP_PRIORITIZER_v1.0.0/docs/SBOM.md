# SBOM / Provenance
Runtime dependencies: none.
Bundled executable surfaces: `app/index.html`, `app/style.css`, `app/app.js`.
Test runtime: Node.js used only for producer verification and is not required by the product.
External packages: none.
