# Architecture
Dependency-free static browser application: HTML + CSS + JavaScript. Ranking is computed locally in the browser from in-memory synthetic records. There is no network request, persistence layer, authentication, telemetry, external API, or backend.
