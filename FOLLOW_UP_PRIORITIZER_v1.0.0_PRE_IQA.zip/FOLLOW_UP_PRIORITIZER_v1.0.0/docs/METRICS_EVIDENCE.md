# Metrics / Evidence
Measured against the bundled synthetic fixture:
- Input records: 5
- Output ranked records: 5
- Overdue promised follow-ups: 2
- Items with visible reasons: 5/5
- Deterministic repeatability on identical input: PASS
- Runtime external dependencies: 0

These are product-fixture measurements only. No claim is made about real-world sales outcomes, conversion lift, or time savings.
