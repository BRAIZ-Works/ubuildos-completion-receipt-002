const sample = [
  {id:'FUP-001',name:'Jordan Lee',company:'Northstar Dental',days_since_contact:6,promised_followup_days_ago:2,opportunity_value:18000,engagement:'high',deadline_days:3,next_action:'Send revised proposal'},
  {id:'FUP-002',name:'Maya Chen',company:'Summit Property Group',days_since_contact:2,promised_followup_days_ago:0,opportunity_value:42000,engagement:'high',deadline_days:8,next_action:'Confirm decision-maker meeting'},
  {id:'FUP-003',name:'Alex Rivera',company:'Harbor HVAC',days_since_contact:11,promised_followup_days_ago:4,opportunity_value:9500,engagement:'medium',deadline_days:1,next_action:'Call about onboarding questions'},
  {id:'FUP-004',name:'Priya Shah',company:'Greenline Services',days_since_contact:4,promised_followup_days_ago:0,opportunity_value:26000,engagement:'medium',deadline_days:14,next_action:'Share comparison sheet'},
  {id:'FUP-005',name:'Sam Brooks',company:'Oak & Field',days_since_contact:15,promised_followup_days_ago:0,opportunity_value:6000,engagement:'low',deadline_days:30,next_action:'Re-engage after quiet period'}
];
function render(filter='all'){
 const ranked=window.FollowUpRanking.prioritize(sample); let view=ranked;
 if(filter==='high')view=ranked.filter(x=>x.score>=45);
 if(filter==='overdue')view=ranked.filter(x=>x.promised_followup_days_ago>0);
 document.querySelector('#count').textContent=ranked.length;
 document.querySelector('#overdue').textContent=ranked.filter(x=>x.promised_followup_days_ago>0).length;
 document.querySelector('#hot').textContent=ranked.filter(x=>x.score>=45).length;
 document.querySelector('#queue').innerHTML=view.map(x=>`<article class="card ${x.score>=45?'high':''}"><div class="rank">#${ranked.indexOf(x)+1}</div><div><div class="name">${x.name} · ${x.company}</div><div class="meta">Next: ${x.next_action}</div></div><div class="score">Score ${x.score}</div><div class="reasons">${x.reasons.map(r=>`<span class="reason">${r.label} <strong>+${r.points}</strong></span>`).join('')}</div></article>`).join('');
}
document.querySelector('#filter').addEventListener('change',e=>render(e.target.value));
document.querySelector('#reset').addEventListener('click',()=>{document.querySelector('#filter').value='all';render();});
window.FollowUpPrioritizer={sample,render};render();
