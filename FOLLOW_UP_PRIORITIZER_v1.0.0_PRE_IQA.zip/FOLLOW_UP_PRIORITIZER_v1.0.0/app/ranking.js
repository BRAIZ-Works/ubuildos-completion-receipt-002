(function(global){
function scoreItem(x){
  let score=0, reasons=[];
  if(x.promised_followup_days_ago>0){const p=Math.min(35,20+x.promised_followup_days_ago*3);score+=p;reasons.push({label:`Promised follow-up overdue by ${x.promised_followup_days_ago}d`,points:p});}
  if(x.deadline_days<=1){score+=25;reasons.push({label:'Deadline within 24h',points:25});}
  else if(x.deadline_days<=3){score+=18;reasons.push({label:`Deadline in ${x.deadline_days}d`,points:18});}
  else if(x.deadline_days<=7){score+=10;reasons.push({label:`Deadline in ${x.deadline_days}d`,points:10});}
  const ev={high:16,medium:9,low:3}[x.engagement]||0;score+=ev;reasons.push({label:`${x.engagement[0].toUpperCase()+x.engagement.slice(1)} engagement`,points:ev});
  const vv=x.opportunity_value>=30000?15:x.opportunity_value>=15000?10:x.opportunity_value>=8000?6:2;score+=vv;reasons.push({label:`Opportunity signal $${x.opportunity_value.toLocaleString()}`,points:vv});
  const age=Math.min(12,Math.floor(x.days_since_contact/3)*3);if(age){score+=age;reasons.push({label:`${x.days_since_contact}d since contact`,points:age});}
  return {...x,score,reasons};
}
function prioritize(items){return items.map(scoreItem).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));}
global.FollowUpRanking={scoreItem,prioritize};
})(typeof window!=='undefined'?window:globalThis);
