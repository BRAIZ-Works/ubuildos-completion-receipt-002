# START HERE
1. Open `app/index.html`.
2. Read the ranked queue from #1 downward.
3. Inspect the reason chips under each item to see why it ranked there.
4. Use the View filter to isolate high-priority or overdue follow-ups.

All bundled names/companies/data are synthetic examples.
